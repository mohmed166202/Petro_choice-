"""
ablation_tracker.py - Controlled Ablation Analysis & Experiment Comparison Tracker
----------------------------------------------------------------------------------
Extracts validation results from local MLflow SQLite, compares each single-variable run
against the baseline and noise floor threshold, marks statistical significance, and generates
the final ablation summary table for the 2-page assessment report.
"""

import sys
import json
from pathlib import Path
from typing import Dict, List, Any

# Ensure project root in sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import pandas as pd
import mlflow


EXPERIMENT_TAXONOMY = {
    "exp0_baseline_seed42": {
        "priority": 0,
        "category": "Baseline",
        "changed_variable": "None (Baseline)",
        "hypothesis": "YOLOv8n default parameters establish reference performance.",
    },
    "exp0_baseline_seed1337": {
        "priority": 0,
        "category": "Sensitivity",
        "changed_variable": "Seed (1337 vs 42)",
        "hypothesis": "Quantifies empirical stochastic run-to-run noise floor.",
    },
    "exp1_scale": {
        "priority": 1,
        "category": "Augmentation",
        "changed_variable": "Scale Jitter (0.7 vs 0.5)",
        "hypothesis": "Enhances feature pyramid representations for ~70% small objects.",
    },
    "exp2_mosaic": {
        "priority": 2,
        "category": "Augmentation",
        "changed_variable": "Mosaic Probability (0.5 vs 1.0)",
        "hypothesis": "Reduces aggressive cropping in dense crowd scenes.",
    },
    "exp3_hsv": {
        "priority": 3,
        "category": "Augmentation",
        "changed_variable": "HSV Saturation (0.4 vs 0.7)",
        "hypothesis": "Reduces false color overfitting across web lighting conditions.",
    },
    "exp4_cls_gain": {
        "priority": 4,
        "category": "Class Imbalance",
        "changed_variable": "Class Loss Gain (1.5 vs 0.5)",
        "hypothesis": "Forces heavier loss penalties for 12.33:1 minority helmet class.",
    },
    "exp5_oversample": {
        "priority": 5,
        "category": "Class Imbalance",
        "changed_variable": "Minority Oversampling (2x)",
        "hypothesis": "Balances gradient updates without touching validation data.",
    },
    "exp6_imgsz_800": {
        "priority": 6,
        "category": "Architecture",
        "changed_variable": "Input Resolution (800 vs 640)",
        "hypothesis": "Increases pixel area of distant heads by 56% to boost small mAP.",
    },
    "exp7_cosine_lr": {
        "priority": 7,
        "category": "Optimization",
        "changed_variable": "Cosine LR Scheduler",
        "hypothesis": "Smoother annealing schedule aids generalization near minima.",
    },
    "exp8_best_combo": {
        "priority": 8,
        "category": "Composite",
        "changed_variable": "Winning Interventions Union",
        "hypothesis": "Additive synergy across validated independent wins.",
    },
}


def load_noise_floor_threshold(reports_dir: Path) -> float:
    """Loads significance threshold from Phase 3 noise floor analysis."""
    noise_file = reports_dir / "seed_sensitivity_noise_floor.json"
    if noise_file.exists():
        with open(noise_file, "r") as f:
            data = json.load(f)
            return float(data.get("decision_rule", {}).get("mde_significance_threshold_map50", 0.005))
    return 0.005  # Default 0.5% threshold if sensitivity check not run yet


def compile_ablation_study(
    db_path: str = "sqlite:///mlflow.db",
    reports_dir: Path = Path("reports")
) -> pd.DataFrame:
    """
    Queries MLflow, extracts runs, compiles comparison dataframe, and exports CSV & Markdown.
    """
    tables_dir = reports_dir / "tables"
    tables_dir.mkdir(parents=True, exist_ok=True)
    
    significance_mde = load_noise_floor_threshold(reports_dir)
    
    mlflow.set_tracking_uri(db_path)
    client = mlflow.tracking.MlflowClient()
    
    experiment = client.get_experiment_by_name("ppe_helmet_detection")
    records = []
    
    if experiment:
        runs = client.search_runs(experiment_ids=[experiment.experiment_id])
        run_data_map = {r.data.tags.get("mlflow.runName", ""): r for r in runs}
    else:
        run_data_map = {}
        
    baseline_run = run_data_map.get("exp0_baseline_seed42")
    baseline_map50 = baseline_run.data.metrics.get("val_mAP50", 0.0) if baseline_run else 0.0
    
    for run_id, meta in EXPERIMENT_TAXONOMY.items():
        run_obj = run_data_map.get(run_id)
        if run_obj:
            m = run_obj.data.metrics
            val_map50 = m.get("val_mAP50", 0.0)
            val_map = m.get("val_mAP50_95", 0.0)
            hat_map50 = m.get("val_hat_mAP50", 0.0)
            no_helmet_map50 = m.get("val_no_helmet_mAP50", 0.0)
            status = "Completed"
        else:
            val_map50 = 0.0
            val_map = 0.0
            hat_map50 = 0.0
            no_helmet_map50 = 0.0
            status = "Pending Execution"
            
        delta = val_map50 - baseline_map50 if baseline_map50 > 0 else 0.0
        
        # Outcome determination
        if status == "Pending Execution":
            outcome = "Pending"
        elif run_id.startswith("exp0"):
            outcome = "Reference"
        elif delta > significance_mde:
            outcome = "WIN (Significant)"
        elif delta < -significance_mde:
            outcome = "REGRESSION"
        else:
            outcome = "NEUTRAL (Within Noise Floor)"
            
        records.append({
            "Run ID": run_id,
            "Category": meta["category"],
            "Changed Variable": meta["changed_variable"],
            "Status": status,
            "Val mAP@50": round(val_map50, 4) if val_map50 > 0 else "-",
            "Val mAP@50-95": round(val_map, 4) if val_map > 0 else "-",
            "Hat mAP@50": round(hat_map50, 4) if hat_map50 > 0 else "-",
            "No-Helmet mAP@50": round(no_helmet_map50, 4) if no_helmet_map50 > 0 else "-",
            "Δ vs Baseline": f"{delta:+.4f}" if baseline_map50 > 0 and val_map50 > 0 else "-",
            "Outcome": outcome
        })
        
    df = pd.DataFrame(records)
    
    # Export CSV
    csv_path = tables_dir / "ablation_study.csv"
    df.to_csv(csv_path, index=False)
    
    # Export Markdown
    md_path = tables_dir / "ablation_study.md"
    with open(md_path, "w", encoding="utf-8") as f:
        f.write("# Controlled Ablation Study: PPE Helmet Detection\n\n")
        f.write(f"- **Significance Threshold (MDE)**: > {significance_mde:.4f} gain in val mAP@50 required.\n")
        f.write("- **Selection Rule**: Model selection uses strictly validation metrics; test set remains untouched.\n\n")
        
        # Pure Python markdown table to eliminate tabulate dependency
        headers = list(df.columns)
        f.write("| " + " | ".join(headers) + " |\n")
        f.write("| " + " | ".join(["---"] * len(headers)) + " |\n")
        for _, row in df.iterrows():
            f.write("| " + " | ".join(str(row[h]) for h in headers) + " |\n")
        f.write("\n")
        
    print(f"\n[SUCCESS] Ablation comparison table compiled:")
    print(f"  CSV:      {csv_path}")
    print(f"  Markdown: {md_path}")
    return df


if __name__ == "__main__":
    compile_ablation_study()
