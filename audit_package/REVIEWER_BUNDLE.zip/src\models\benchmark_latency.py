"""
benchmark_latency.py - Standardized CPU Inference Latency Benchmarking Protocol
-------------------------------------------------------------------------------
Measures real-time single-image inference latency on CPU:
1. Records host hardware specifications (CPU, logical cores, RAM).
2. Sets explicit thread affinity (intra_op_num_threads = 4).
3. Executes 50 warm-up runs to stabilize CPU caches.
4. Timed 200 benchmark iterations with time.perf_counter().
5. Calculates Mean, p50 (median), p90, p95, Standard Deviation, and Throughput (FPS).
6. Exports reports/tables/latency_benchmark.json and markdown table.
"""

import sys
import time
import json
import platform
from pathlib import Path
from typing import Dict, Any

# Ensure project root in sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import numpy as np
import onnxruntime as ort
import psutil

from src.models.onnx_engine import PPEOnnxEngine


def get_hardware_specs() -> Dict[str, Any]:
    """Retrieves host hardware specifications."""
    return {
        "os": platform.platform(),
        "processor": platform.processor(),
        "cpu_name": platform.machine(),
        "physical_cores": psutil.cpu_count(logical=False),
        "logical_processors": psutil.cpu_count(logical=True),
        "total_ram_gb": round(psutil.virtual_memory().total / (1024 ** 3), 2),
    }


def benchmark_cpu_latency(
    model_path: str = "models/model.onnx",
    reports_dir: Path = Path("reports"),
    warmup_runs: int = 50,
    benchmark_runs: int = 200,
    intra_threads: int = 4,
    img_size: int = 640
) -> Dict[str, Any]:
    """
    Executes standardized CPU latency benchmark.
    """
    tables_dir = reports_dir / "tables"
    tables_dir.mkdir(parents=True, exist_ok=True)
    
    print(f"\n=======================================================")
    print(f"[CPU BENCHMARK] Latency Protocol (Batch Size = 1)")
    print(f"  Model:           {model_path}")
    print(f"  Intra Threads:   {intra_threads}")
    print(f"  Warm-up Runs:    {warmup_runs}")
    print(f"  Timed Runs:      {benchmark_runs}")
    print(f"=======================================================\n")
    
    engine = PPEOnnxEngine(model_path=model_path, num_threads=intra_threads)
    dummy_img = (np.random.rand(img_size, img_size, 3) * 255).astype(np.uint8)
    
    # Pre-process once to measure pure model forward pass + post-processing
    blob, scale, pad, orig_dims = engine.preprocess(dummy_img)
    
    # 1. Warm-up Phase
    print(f"[INFO] Warming up CPU caches over {warmup_runs} iterations...")
    for _ in range(warmup_runs):
        _ = engine.session.run(None, {engine.input_name: blob})
        
    # 2. Timed Benchmark Phase (End-to-End: Preprocess + Inference + Postprocess)
    latencies_ms = []
    pure_inference_ms = []
    
    print(f"[INFO] Measuring {benchmark_runs} benchmark iterations...")
    for _ in range(benchmark_runs):
        t0 = time.perf_counter()
        
        # Preprocessing
        b, s, p, dims = engine.preprocess(dummy_img)
        
        # Inference
        t_inf_start = time.perf_counter()
        raw_out = engine.session.run(None, {engine.input_name: b})
        t_inf_end = time.perf_counter()
        
        # Postprocessing
        _ = engine.postprocess(raw_out[0], s, p, dims)
        
        t_total = (time.perf_counter() - t0) * 1000.0
        t_inf = (t_inf_end - t_inf_start) * 1000.0
        
        latencies_ms.append(t_total)
        pure_inference_ms.append(t_inf)

    # 3. Compute Percentiles
    lat_arr = np.array(latencies_ms)
    inf_arr = np.array(pure_inference_ms)
    
    mean_lat = float(np.mean(lat_arr))
    p50_lat = float(np.percentile(lat_arr, 50))
    p90_lat = float(np.percentile(lat_arr, 90))
    p95_lat = float(np.percentile(lat_arr, 95))
    std_lat = float(np.std(lat_arr))
    fps = float(1000.0 / mean_lat) if mean_lat > 0 else 0.0
    
    mean_inf = float(np.mean(inf_arr))
    p50_inf = float(np.percentile(inf_arr, 50))
    p95_inf = float(np.percentile(inf_arr, 95))
    
    hw_specs = get_hardware_specs()
    
    results = {
        "hardware_environment": hw_specs,
        "benchmark_protocol": {
            "batch_size": 1,
            "warmup_iterations": warmup_runs,
            "timed_iterations": benchmark_runs,
            "intra_op_threads": intra_threads,
            "input_resolution": f"{img_size}x{img_size}",
        },
        "end_to_end_latency_ms": {
            "mean": round(mean_lat, 2),
            "median_p50": round(p50_lat, 2),
            "p90": round(p90_lat, 2),
            "p95": round(p95_lat, 2),
            "std_dev": round(std_lat, 2),
            "throughput_fps": round(fps, 1),
        },
        "pure_onnx_inference_ms": {
            "mean": round(mean_inf, 2),
            "median_p50": round(p50_inf, 2),
            "p95": round(p95_inf, 2),
        }
    }
    
    # Save JSON
    json_path = tables_dir / "latency_benchmark.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2)
        
    # Save Markdown Table
    md_path = tables_dir / "latency_benchmark.md"
    with open(md_path, "w", encoding="utf-8") as f:
        f.write("# CPU Inference Latency Benchmark Report\n\n")
        f.write(f"- **CPU**: {hw_specs['processor']} ({hw_specs['logical_processors']} threads)\n")
        f.write(f"- **RAM**: {hw_specs['total_ram_gb']} GB\n")
        f.write(f"- **Batch Size**: 1 (Real-Time Edge/API)\n")
        f.write(f"- **Threads**: {intra_threads} intra-op threads\n\n")
        f.write("| Metric | End-to-End Latency (ms) | Pure ONNX Forward Pass (ms) |\n")
        f.write("| --- | --- | --- |\n")
        f.write(f"| **Mean** | {mean_lat:.2f} ms | {mean_inf:.2f} ms |\n")
        f.write(f"| **Median (p50)** | {p50_lat:.2f} ms | {p50_inf:.2f} ms |\n")
        f.write(f"| **p90** | {p90_lat:.2f} ms | - |\n")
        f.write(f"| **p95** | {p95_lat:.2f} ms | {p95_inf:.2f} ms |\n")
        f.write(f"| **Throughput** | **{fps:.1f} FPS** | **{1000.0/mean_inf:.1f} FPS** |\n")
        f.write("\n")
        
    print(f"\n[SUCCESS] CPU Latency Benchmark Complete:")
    print(f"  Mean Latency:    {mean_lat:.2f} ms ({fps:.1f} FPS)")
    print(f"  Median (p50):    {p50_lat:.2f} ms")
    print(f"  p95 Latency:     {p95_lat:.2f} ms")
    print(f"  Saved to:        {json_path} and {md_path}")
    return results


if __name__ == "__main__":
    benchmark_cpu_latency()
