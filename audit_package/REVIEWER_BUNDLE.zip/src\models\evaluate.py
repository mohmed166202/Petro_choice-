"""
evaluate.py - Final Untouched Test Set Evaluation Pipeline
----------------------------------------------------------
Executes the SINGLE FINAL PASS on the write-locked test set:
1. Enforces authorized evaluation caller validation.
2. Ingests optimal confidence threshold tau* calibrated on validation data.
3. Computes test mAP@50, mAP@50-95, per-class Precision/Recall, and Confusion Matrix.
4. Logs final evaluation metrics to local MLflow SQLite registry.
5. Exports reports/test_metrics_summary.json.
"""

import sys
import json
import argparse
from pathlib import Path
from typing import Dict, Any

# Ensure project root in sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import yaml
import mlflow
from ultralytics import YOLO

from src.utils.guard import guard_test_set_access


def load_optimal_threshold(reports_dir: Path) -> float:
    """Loads optimal threshold chosen strictly on validation set."""
    thresh_file = reports_dir / "optimal_threshold_justification.json"
    if thresh_file.exists():
        with open(thresh_file, "r") as f:
            data = json.load(f)
            return float(data.get("optimal_threshold", 0.40))
    return 0.40  # Default industrial threshold if optimizer not run


def run_test_evaluation(
    weights_path: str = "models/exp8_best_combo/weights/best.pt",
    test_split_path: str = "data/splits/test.txt",
    reports_dir: Path = Path("reports"),
    tracking_uri: str = "sqlite:///mlflow.db"
) -> Dict[str, Any]:
    """
    Executes single evaluation pass on untouched test set.
    """
    # 1. Access guard
    guard_test_set_access("evaluate.py")
    
    # Check weights fallback
    if not Path(weights_path).exists():
        fallback_candidates = [
            "models/exp0_baseline_seed42/weights/best.pt",
            "yolov8n.pt"
        ]
        for c in fallback_candidates:
            if Path(c).exists():
                print(f"[WARN] Requested weights '{weights_path}' not found. Using fallback '{c}'.")
                weights_path = c
                break
                
    optimal_tau = load_optimal_threshold(reports_dir)
    print(f"\n=======================================================")
    print(f"[TEST EVALUATION] Starting Single Pass on Untouched Test Set")
    print(f"  Model Weights:        {weights_path}")
    print(f"  Confidence Threshold: {optimal_tau:.2f} (from validation calibration)")
    print(f"  Test Split:           {test_split_path}")
    print(f"=======================================================\n")
    
    # Create temporary evaluation dataset YAML specifically for test split
    temp_test_yaml = reports_dir / "temp_test_eval.yaml"
    with open(temp_test_yaml, "w", encoding="utf-8") as f:
        yaml.dump({
            "path": ".",
            "val": test_split_path,
            "names": {0: "hat", 1: "no_helmet"}
        }, f)
        
    try:
        model = YOLO(weights_path)
        metrics = model.val(
            data=str(temp_test_yaml),
            conf=optimal_tau,
            iou=0.5,
            split="val",  # Evaluate on the set defined in val key (our test.txt)
            verbose=True,
            save_json=True
        )
    finally:
        if temp_test_yaml.exists():
            temp_test_yaml.unlink()

    # Extract final test metrics
    test_map50 = float(metrics.box.map50)
    test_map = float(metrics.box.map)
    test_p = float(metrics.box.mp)
    test_r = float(metrics.box.mr)
    
    per_class_map50 = metrics.box.maps
    hat_map50 = float(per_class_map50[0]) if len(per_class_map50) > 0 else 0.0
    no_helmet_map50 = float(per_class_map50[1]) if len(per_class_map50) > 1 else 0.0
    
    summary = {
        "evaluation_target": "Untouched Test Set (data/splits/test.txt)",
        "model_weights": weights_path,
        "confidence_threshold": optimal_tau,
        "overall_metrics": {
            "test_mAP50": round(test_map50, 4),
            "test_mAP50_95": round(test_map, 4),
            "test_precision": round(test_p, 4),
            "test_recall": round(test_r, 4),
        },
        "per_class_metrics": {
            "hat_mAP50": round(hat_map50, 4),
            "no_helmet_mAP50": round(no_helmet_map50, 4),
        }
    }
    
    # Save test metrics JSON
    out_json = reports_dir / "test_metrics_summary.json"
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
        
    # Log to MLflow
    mlflow.set_tracking_uri(tracking_uri)
    mlflow.set_experiment("ppe_helmet_detection")
    with mlflow.start_run(run_name="final_test_evaluation"):
        mlflow.log_param("evaluated_split", "test")
        mlflow.log_param("weights", weights_path)
        mlflow.log_param("optimal_confidence_threshold", optimal_tau)
        mlflow.log_metric("test_mAP50", test_map50)
        mlflow.log_metric("test_mAP50_95", test_map)
        mlflow.log_metric("test_hat_mAP50", hat_map50)
        mlflow.log_metric("test_no_helmet_mAP50", no_helmet_map50)
        mlflow.log_artifact(str(out_json), artifact_path="test_results")
        
    print(f"\n[SUCCESS] Untouched Test Set Evaluation Complete.")
    print(f"  Test mAP@50:        {test_map50:.4f}")
    print(f"  Test mAP@50-95:     {test_map:.4f}")
    print(f"  Hat mAP@50:         {hat_map50:.4f}")
    print(f"  No-Helmet mAP@50:   {no_helmet_map50:.4f}")
    print(f"  Saved report to {out_json}")
    return summary


def parse_args():
    parser = argparse.ArgumentParser(description="Evaluate on untouched test set")
    parser.add_argument("--weights", type=str, default="models/exp8_best_combo/weights/best.pt")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    run_test_evaluation(weights_path=args.weights)
