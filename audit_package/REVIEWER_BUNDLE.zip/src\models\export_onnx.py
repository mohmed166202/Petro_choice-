"""
export_onnx.py - PyTorch to ONNX Model Exporter with Validation
---------------------------------------------------------------
Exports trained YOLOv8 PyTorch checkpoint to optimized ONNX format:
1. Static input shape: 1 x 3 x 640 x 640 for CPU inference stability.
2. Opset 17 target for broad cross-platform runtime compatibility.
3. Decouples NMS: raw tensor graph export preserves explainable Python post-processing.
4. Structural verification via onnx.checker.
"""

import sys
import argparse
from pathlib import Path
from typing import Dict, Any

# Ensure project root in sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import onnx
import onnxruntime as ort
import numpy as np
from ultralytics import YOLO


def export_model_to_onnx(
    weights_path: str = "models/exp8_best_combo/weights/best.pt",
    output_dir: Path = Path("models"),
    imgsz: int = 640,
    opset: int = 17
) -> Path:
    """
    Exports PyTorch model to ONNX format and verifies graph validity.
    """
    # Check fallback weights
    weights = Path(weights_path)
    if not weights.exists():
        fallback_candidates = [
            "models/exp0_baseline_seed42/weights/best.pt",
            "yolov8n.pt"
        ]
        for c in fallback_candidates:
            if Path(c).exists():
                print(f"[WARN] Requested weights '{weights_path}' not found. Using fallback '{c}'.")
                weights = Path(c)
                break
                
    output_dir.mkdir(parents=True, exist_ok=True)
    target_onnx_path = output_dir / "model.onnx"
    
    print(f"\n=======================================================")
    print(f"[ONNX EXPORT] Exporting {weights} to ONNX")
    print(f"  Target File:  {target_onnx_path}")
    print(f"  Image Size:   {imgsz}x{imgsz} (Static Shape)")
    print(f"  Opset:        {opset}")
    print(f"=======================================================\n")
    
    # 1. Export via Ultralytics exporter
    model = YOLO(str(weights))
    exported_file = model.export(
        format="onnx",
        imgsz=imgsz,
        opset=opset,
        dynamic=False,
        simplify=True,
        nms=False  # Keep NMS decoupled in Python for explainability
    )
    
    exported_path = Path(exported_file)
    if exported_path.resolve() != target_onnx_path.resolve():
        if target_onnx_path.exists():
            target_onnx_path.unlink()
        exported_path.replace(target_onnx_path)
        
    # 2. Structural verification via onnx.checker
    print("[INFO] Verifying ONNX graph with onnx.checker...")
    onnx_model = onnx.load(str(target_onnx_path))
    onnx.checker.check_model(onnx_model)
    
    # 3. Functional verification via ONNX Runtime session
    print("[INFO] Testing runtime session inference on dummy tensor...")
    session = ort.InferenceSession(str(target_onnx_path), providers=["CPUExecutionProvider"])
    input_name = session.get_inputs()[0].name
    dummy_input = np.random.randn(1, 3, imgsz, imgsz).astype(np.float32)
    output = session.run(None, {input_name: dummy_input})
    
    file_size_mb = target_onnx_path.stat().st_size / (1024 * 1024)
    print(f"\n[SUCCESS] ONNX Model Exported & Validated:")
    print(f"  Path:       {target_onnx_path}")
    print(f"  File Size:  {file_size_mb:.2f} MB")
    print(f"  Out Tensor: {output[0].shape} (Channels, Anchors)")
    return target_onnx_path


def parse_args():
    parser = argparse.ArgumentParser(description="Export PyTorch model to ONNX")
    parser.add_argument("--weights", type=str, default="models/exp8_best_combo/weights/best.pt")
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--opset", type=int, default=17)
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    export_model_to_onnx(weights_path=args.weights, imgsz=args.imgsz, opset=args.opset)
