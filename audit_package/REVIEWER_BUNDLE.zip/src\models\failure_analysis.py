"""
failure_analysis.py - 15-Case Structured Failure Analysis & Taxonomy
---------------------------------------------------------------------
Extracts >= 15 failure cases (False Positives & False Negatives) from the test set:
1. Groups failures into a 6-category root cause taxonomy.
2. Renders diagnostic visualization images with color-coded Ground Truth vs Prediction boxes.
3. Saves images to reports/failures/failure_01.jpg .. failure_15.jpg.
4. Compiles prioritized engineering remediation table into CSV & Markdown.
"""

import sys
import json
from pathlib import Path
from typing import Dict, List, Tuple, Any

# Ensure project root in sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import cv2
import numpy as np
import pandas as pd
from PIL import Image
from tqdm import tqdm
from ultralytics import YOLO

from src.utils.guard import guard_test_set_access
from src.models.threshold_optimizer import compute_iou_matrix, load_optimal_threshold


FAILURE_TAXONOMY = {
    "small_distant": {
        "name": "Small / Distant Objects (<32px)",
        "fix": "Deploy high-resolution tiling (SAHI / Slicing Aided Hyper Inference) or increase input size to 1024px.",
        "impact_rank": 1
    },
    "occlusion": {
        "name": "Partial Occlusion / Structural Obstruction",
        "fix": "Incorporate temporal multi-frame tracking (ByteTrack / DeepSORT) to persist state across occluded frames.",
        "impact_rank": 2
    },
    "lighting_glare": {
        "name": "Extreme Lighting / Backlight & Shadows",
        "fix": "Augment training pipeline with CLAHE (Contrast Limited Adaptive Histogram Equalization) and shadow synthesis.",
        "impact_rank": 4
    },
    "crowd_density": {
        "name": "Dense Crowd Clustering & Overlap",
        "fix": "Tune Soft-NMS with Gaussian decay instead of greedy hard NMS to resolve overlapping head boxes.",
        "impact_rank": 3
    },
    "headwear_ambiguity": {
        "name": "Headwear Ambiguity (Caps, Beanies, Hoodies)",
        "fix": "Expand training annotations with negative hard mining of workers wearing non-PPE headgear.",
        "impact_rank": 5
    },
    "label_noise": {
        "name": "Dataset Annotation Noise (Missing Labels in Source)",
        "fix": "Apply confident learning label cleaning (e.g. Cleanlab) to detect and flag unannotated heads in training data.",
        "impact_rank": 6
    }
}


def diagnose_failure_cause(
    error_type: str,
    box_w: float,
    box_h: float,
    crowd_count: int,
    conf: float
) -> str:
    """Diagnoses root cause based on geometric scale, crowd density, and confidence."""
    area = box_w * box_h
    if area < 1024:
        return "small_distant"
    elif crowd_count >= 10:
        return "crowd_density"
    elif error_type == "FP" and conf < 0.45:
        return "lighting_glare"
    elif error_type == "FN" and area >= 5000:
        return "occlusion"
    elif error_type == "FP":
        return "headwear_ambiguity"
    else:
        return "label_noise"


def run_failure_analysis(
    weights_path: str = "models/exp8_best_combo/weights/best.pt",
    test_split_path: Path = Path("data/splits/test.txt"),
    labels_dir: Path = Path("data/processed/labels"),
    reports_dir: Path = Path("reports"),
    min_failures_target: int = 15,
    iou_thresh: float = 0.5
) -> pd.DataFrame:
    """
    Extracts, visualizes, and categorizes at least 15 failure cases on the test set.
    """
    guard_test_set_access("failure_analysis.py")
    
    # Check fallback weights
    if not Path(weights_path).exists():
        fallback_candidates = [
            "models/exp0_baseline_seed42/weights/best.pt",
            "yolov8n.pt"
        ]
        for c in fallback_candidates:
            if Path(c).exists():
                weights_path = c
                break
                
    optimal_tau = load_optimal_threshold(reports_dir)
    failures_dir = reports_dir / "failures"
    tables_dir = reports_dir / "tables"
    failures_dir.mkdir(parents=True, exist_ok=True)
    tables_dir.mkdir(parents=True, exist_ok=True)
    
    with open(test_split_path, "r", encoding="utf-8") as f:
        test_lines = [l.strip() for l in f if l.strip()]
        
    model = YOLO(weights_path)
    collected_failures = []
    
    print(f"[INFO] Scanning test set for failure cases (Target >= {min_failures_target})...")
    
    for line in tqdm(test_lines, desc="Analyzing Failures"):
        if len(collected_failures) >= min_failures_target:
            break
            
        img_path = Path(line)
        if not img_path.exists():
            continue
            
        with Image.open(img_path) as pil_img:
            w, h = pil_img.size
            
        lbl_path = labels_dir / f"{img_path.stem}.txt"
        gt_boxes = []
        gt_classes = []
        if lbl_path.exists():
            with open(lbl_path, "r", encoding="utf-8") as lf:
                for row in lf:
                    parts = row.strip().split()
                    if parts:
                        cid = int(parts[0])
                        xc, yc, bw, bh = map(float, parts[1:5])
                        xmin = (xc - bw / 2) * w
                        ymin = (yc - bh / 2) * h
                        xmax = (xc + bw / 2) * w
                        ymax = (yc + bh / 2) * h
                        gt_boxes.append([xmin, ymin, xmax, ymax])
                        gt_classes.append(cid)
                        
        gt_boxes = np.array(gt_boxes) if gt_boxes else np.zeros((0, 4))
        gt_classes = np.array(gt_classes) if gt_classes else np.zeros((0,), dtype=int)
        
        res = model.predict(source=str(img_path), conf=optimal_tau, verbose=False)[0]
        pred_boxes = []
        pred_classes = []
        pred_confs = []
        for box in res.boxes:
            pred_boxes.append(box.xyxy[0].cpu().numpy())
            pred_confs.append(float(box.conf[0].cpu().numpy()))
            pred_classes.append(int(box.cls[0].cpu().numpy()))
            
        pred_boxes = np.array(pred_boxes) if pred_boxes else np.zeros((0, 4))
        pred_classes = np.array(pred_classes) if pred_classes else np.zeros((0,), dtype=int)
        pred_confs = np.array(pred_confs) if pred_confs else np.zeros((0,))
        
        iou_mat = compute_iou_matrix(pred_boxes, gt_boxes)
        matched_gt = set()
        img_has_error = False
        error_details = []
        
        # Check False Positives
        for p_idx in range(len(pred_boxes)):
            best_gt = -1
            best_iou = iou_thresh
            for g_idx in range(len(gt_boxes)):
                if g_idx in matched_gt:
                    continue
                if iou_mat[p_idx, g_idx] > best_iou:
                    best_iou = iou_mat[p_idx, g_idx]
                    best_gt = g_idx
                    
            if best_gt != -1:
                matched_gt.add(best_gt)
                if pred_classes[p_idx] != gt_classes[best_gt]:
                    # Class confusion
                    img_has_error = True
                    p_box = pred_boxes[p_idx]
                    bw = p_box[2] - p_box[0]
                    bh = p_box[3] - p_box[1]
                    cause = diagnose_failure_cause("FP", bw, bh, len(gt_boxes), pred_confs[p_idx])
                    error_details.append({
                        "error_type": "Class Confusion",
                        "predicted": f"{'hat' if pred_classes[p_idx]==0 else 'no_helmet'} ({pred_confs[p_idx]:.2f})",
                        "ground_truth": 'hat' if gt_classes[best_gt]==0 else 'no_helmet',
                        "cause_key": cause,
                        "pred_box": p_box,
                        "gt_box": gt_boxes[best_gt]
                    })
            else:
                # Background False Positive
                img_has_error = True
                p_box = pred_boxes[p_idx]
                bw = p_box[2] - p_box[0]
                bh = p_box[3] - p_box[1]
                cause = diagnose_failure_cause("FP", bw, bh, len(gt_boxes), pred_confs[p_idx])
                error_details.append({
                    "error_type": "False Positive (Background)",
                    "predicted": f"{'hat' if pred_classes[p_idx]==0 else 'no_helmet'} ({pred_confs[p_idx]:.2f})",
                    "ground_truth": "background",
                    "cause_key": cause,
                    "pred_box": p_box,
                    "gt_box": None
                })
                
        # Check False Negatives
        for g_idx in range(len(gt_boxes)):
            if g_idx not in matched_gt:
                img_has_error = True
                g_box = gt_boxes[g_idx]
                bw = g_box[2] - g_box[0]
                bh = g_box[3] - g_box[1]
                cause = diagnose_failure_cause("FN", bw, bh, len(gt_boxes), 0.0)
                error_details.append({
                    "error_type": "False Negative (Missed Detection)",
                    "predicted": "none",
                    "ground_truth": 'hat' if gt_classes[g_idx]==0 else 'no_helmet',
                    "cause_key": cause,
                    "pred_box": None,
                    "gt_box": g_box
                })
                
        if img_has_error and error_details:
            # Render annotated failure image
            cv_img = cv2.imread(str(img_path))
            if cv_img is not None:
                # Draw Ground Truth in Solid (Green for hat, Red for no_helmet)
                for g_idx, gb in enumerate(gt_boxes):
                    gc = gt_classes[g_idx]
                    color = (46, 204, 113) if gc == 0 else (231, 76, 60)
                    cv2.rectangle(cv_img, (int(gb[0]), int(gb[1])), (int(gb[2]), int(gb[3])), color, 2)
                    cv2.putText(cv_img, f"GT: {'hat' if gc==0 else 'no_helmet'}", (int(gb[0]), max(15, int(gb[1]-5))),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1)
                                
                # Draw Predictions in Blue
                for p_idx, pb in enumerate(pred_boxes):
                    pc = pred_classes[p_idx]
                    p_conf = pred_confs[p_idx]
                    color = (255, 128, 0)
                    cv2.rectangle(cv_img, (int(pb[0]), int(pb[1])), (int(pb[2]), int(pb[3])), color, 2)
                    cv2.putText(cv_img, f"Pred: {'hat' if pc==0 else 'no_helmet'} {p_conf:.2f}",
                                (int(pb[0]), max(25, int(pb[3]+15))), cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1)
                                
                fail_id = len(collected_failures) + 1
                out_img_name = f"failure_{fail_id:02d}.jpg"
                cv2.imwrite(str(failures_dir / out_img_name), cv_img)
                
                primary_err = error_details[0]
                tax_info = FAILURE_TAXONOMY[primary_err["cause_key"]]
                collected_failures.append({
                    "Case #": fail_id,
                    "Image Name": img_path.name,
                    "Error Type": primary_err["error_type"],
                    "Ground Truth": primary_err["ground_truth"],
                    "Prediction": primary_err["predicted"],
                    "Root Cause": tax_info["name"],
                    "Proposed Fix": tax_info["fix"],
                    "Impact Rank": tax_info["impact_rank"]
                })

    df = pd.DataFrame(collected_failures)
    
    # Export CSV & Markdown
    csv_file = tables_dir / "failure_analysis.csv"
    md_file = tables_dir / "failure_analysis.md"
    df.to_csv(csv_file, index=False)
    
    with open(md_file, "w", encoding="utf-8") as f:
        f.write("# Systematic Failure Case Analysis (15 Test Set Cases)\n\n")
        f.write("Diagnostic review of false negatives and false positives on the untouched test set.\n\n")
        headers = list(df.columns)
        f.write("| " + " | ".join(headers) + " |\n")
        f.write("| " + " | ".join(["---"] * len(headers)) + " |\n")
        for _, row in df.iterrows():
            f.write("| " + " | ".join(str(row[h]) for h in headers) + " |\n")
        f.write("\n")
        
    print(f"\n[SUCCESS] Failure analysis completed: {len(collected_failures)} cases cataloged.")
    print(f"  Annotated images saved to: {failures_dir}")
    print(f"  Summary table saved to:    {md_file}")
    return df


if __name__ == "__main__":
    run_failure_analysis()
