"""
noise_floor.py - Baseline Seed-Sensitivity & Experimental Noise Floor Estimator
-------------------------------------------------------------------------------
Analyzes run-to-run variance between Seed 42 and Seed 1337:
1. Calculates delta across mAP@50, mAP@50-95, and per-class metrics.
2. Establishes the Minimum Detectable Effect (MDE) threshold (2x noise floor).
3. Exports formal findings to reports/seed_sensitivity_noise_floor.json.
"""

import sys
import json
from pathlib import Path
from typing import Dict, Any

# Ensure project root in sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import mlflow


def calculate_noise_floor(
    run_a_name: str = "exp0_baseline_seed42",
    run_b_name: str = "exp0_baseline_seed1337",
    db_path: str = "sqlite:///mlflow.db",
    reports_dir: Path = Path("reports")
) -> Dict[str, Any]:
    """
    Queries MLflow for Seed 42 and Seed 1337 runs and computes noise floor metrics.
    """
    mlflow.set_tracking_uri(db_path)
    client = mlflow.tracking.MlflowClient()
    
    experiment = client.get_experiment_by_name("ppe_helmet_detection")
    if not experiment:
        raise ValueError("MLflow experiment 'ppe_helmet_detection' not found.")
        
    runs = client.search_runs(experiment_ids=[experiment.experiment_id])
    
    run_a = None
    run_b = None
    for r in runs:
        r_name = r.data.tags.get("mlflow.runName", "")
        if r_name == run_a_name:
            run_a = r
        elif r_name == run_b_name:
            run_b = r
            
    if not run_a or not run_b:
        print(f"[WARN] Both runs ('{run_a_name}' and '{run_b_name}') must be completed.")
        return {}
        
    m_a = run_a.data.metrics
    m_b = run_b.data.metrics
    
    delta_map50 = abs(m_a.get("val_mAP50", 0.0) - m_b.get("val_mAP50", 0.0))
    delta_map = abs(m_a.get("val_mAP50_95", 0.0) - m_b.get("val_mAP50_95", 0.0))
    delta_hat = abs(m_a.get("val_hat_mAP50", 0.0) - m_b.get("val_hat_mAP50", 0.0))
    delta_no_helmet = abs(m_a.get("val_no_helmet_mAP50", 0.0) - m_b.get("val_no_helmet_mAP50", 0.0))
    
    # Statistical decision threshold: 2x noise floor
    significance_threshold_map50 = round(2.0 * delta_map50, 4)
    
    noise_summary = {
        "runs_analyzed": [run_a_name, run_b_name],
        "metrics_seed42": {
            "val_mAP50": m_a.get("val_mAP50", 0.0),
            "val_mAP50_95": m_a.get("val_mAP50_95", 0.0),
            "val_hat_mAP50": m_a.get("val_hat_mAP50", 0.0),
            "val_no_helmet_mAP50": m_a.get("val_no_helmet_mAP50", 0.0),
        },
        "metrics_seed1337": {
            "val_mAP50": m_b.get("val_mAP50", 0.0),
            "val_mAP50_95": m_b.get("val_mAP50_95", 0.0),
            "val_hat_mAP50": m_b.get("val_hat_mAP50", 0.0),
            "val_no_helmet_mAP50": m_b.get("val_no_helmet_mAP50", 0.0),
        },
        "noise_floor_deltas": {
            "delta_mAP50": round(delta_map50, 4),
            "delta_mAP50_95": round(delta_map, 4),
            "delta_hat_mAP50": round(delta_hat, 4),
            "delta_no_helmet_mAP50": round(delta_no_helmet, 4),
        },
        "decision_rule": {
            "mde_significance_threshold_map50": significance_threshold_map50,
            "rule": f"Phase 4 ablations must improve val_mAP50 by > {significance_threshold_map50} to reject null hypothesis."
        }
    }
    
    reports_dir.mkdir(parents=True, exist_ok=True)
    out_file = reports_dir / "seed_sensitivity_noise_floor.json"
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(noise_summary, f, indent=2)
        
    print(f"\n[RESULT] Seed Sensitivity & Noise Floor Analysis Complete.")
    print(f"  Delta mAP@50 (Noise Floor):         {delta_map50:.4f}")
    print(f"  Significance Threshold (2x Noise):  {significance_threshold_map50:.4f}")
    print(f"  Saved report to {out_file}")
    
    return noise_summary


if __name__ == "__main__":
    calculate_noise_floor()
