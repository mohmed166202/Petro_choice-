"""
onnx_engine.py - Pure Python Pre/Post-Processing & ONNX Runtime Inference Engine
---------------------------------------------------------------------------------
Decoupled inference engine:
1. Letterbox resizing and RGB normalization in Python.
2. ONNX Runtime CPU session execution.
3. Pure Python post-processing: coordinate de-padding and greedy Non-Maximum Suppression (NMS).
Used across ONNX parity tests, CPU latency benchmarking, and the Phase 7 FastAPI service.
"""

from pathlib import Path
from typing import Dict, List, Tuple, Any, Optional
import numpy as np
import cv2
import onnxruntime as ort


ID_TO_CLASS = {
    0: "hat",
    1: "no_helmet"
}


def letterbox(
    img: np.ndarray,
    target_shape: Tuple[int, int] = (640, 640),
    color: Tuple[int, int, int] = (114, 114, 114)
) -> Tuple[np.ndarray, float, Tuple[float, float]]:
    """
    Resizes image to target shape with aspect-ratio preserving padding.
    
    Returns:
        padded_img, scale_ratio, (pad_left, pad_top)
    """
    shape = img.shape[:2]  # [height, width]
    
    # Scale ratio (new / old)
    r = min(target_shape[0] / shape[0], target_shape[1] / shape[1])
    
    # Unpadded dimensions
    new_unpad = (int(round(shape[1] * r)), int(round(shape[0] * r)))
    dw = target_shape[1] - new_unpad[0]  # width padding
    dh = target_shape[0] - new_unpad[1]  # height padding
    
    # Divide padding evenly
    dw /= 2.0
    dh /= 2.0
    
    if shape[::-1] != new_unpad:
        img_resized = cv2.resize(img, new_unpad, interpolation=cv2.INTER_LINEAR)
    else:
        img_resized = img
        
    top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
    left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
    
    padded_img = cv2.copyMakeBorder(
        img_resized, top, bottom, left, right, cv2.BORDER_CONSTANT, value=color
    )
    return padded_img, r, (dw, dh)


def nms_cpu(
    boxes: np.ndarray,
    scores: np.ndarray,
    iou_threshold: float = 0.45
) -> List[int]:
    """
    Pure Python greedy Non-Maximum Suppression (NMS).
    
    Args:
        boxes: np.ndarray of shape (N, 4) in [x1, y1, x2, y2]
        scores: np.ndarray of shape (N,)
        iou_threshold: float
        
    Returns:
        List of selected indices.
    """
    if len(boxes) == 0:
        return []
        
    x1 = boxes[:, 0]
    y1 = boxes[:, 1]
    x2 = boxes[:, 2]
    y2 = boxes[:, 3]
    areas = (x2 - x1) * (y2 - y1)
    
    order = scores.argsort()[::-1]
    keep = []
    
    while order.size > 0:
        i = order[0]
        keep.append(int(i))
        
        xx1 = np.maximum(x1[i], x1[order[1:]])
        yy1 = np.maximum(y1[i], y1[order[1:]])
        xx2 = np.minimum(x2[i], x2[order[1:]])
        yy2 = np.minimum(y2[i], y2[order[1:]])
        
        w = np.maximum(0.0, xx2 - xx1)
        h = np.maximum(0.0, yy2 - yy1)
        inter = w * h
        union = areas[i] + areas[order[1:]] - inter
        iou = np.where(union > 0, inter / union, 0.0)
        
        inds = np.where(iou <= iou_threshold)[0]
        order = order[inds + 1]
        
    return keep


class PPEOnnxEngine:
    """
    High-performance, decoupled ONNX Runtime inference engine for PPE detection.
    """
    def __init__(
        self,
        model_path: str = "models/model.onnx",
        num_threads: int = 4
    ):
        path = Path(model_path)
        if not path.exists():
            raise FileNotFoundError(f"ONNX model file not found: {model_path}")
            
        opts = ort.SessionOptions()
        opts.intra_op_num_threads = num_threads
        opts.inter_op_num_threads = 1
        opts.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        
        self.session = ort.InferenceSession(
            str(path),
            sess_options=opts,
            providers=["CPUExecutionProvider"]
        )
        
        input_info = self.session.get_inputs()[0]
        self.input_name = input_info.name
        self.input_shape = input_info.shape  # e.g. [1, 3, 640, 640]
        self.img_h = self.input_shape[2] if isinstance(self.input_shape[2], int) else 640
        self.img_w = self.input_shape[3] if isinstance(self.input_shape[3], int) else 640

    def preprocess(self, img_bgr: np.ndarray) -> Tuple[np.ndarray, float, Tuple[float, float], Tuple[int, int]]:
        """
        Letterbox resizing, color conversion (BGR to RGB), and normalization.
        """
        orig_h, orig_w = img_bgr.shape[:2]
        padded_img, scale, (dw, dh) = letterbox(img_bgr, (self.img_h, self.img_w))
        
        # BGR to RGB
        img_rgb = cv2.cvtColor(padded_img, cv2.COLOR_BGR2RGB)
        
        # Transpose: (H, W, C) -> (1, C, H, W)
        blob = img_rgb.transpose(2, 0, 1).astype(np.float32) / 255.0
        blob = np.expand_dims(blob, axis=0)
        blob = np.ascontiguousarray(blob)
        return blob, scale, (dw, dh), (orig_w, orig_h)

    def postprocess(
        self,
        raw_output: np.ndarray,
        scale: float,
        pad: Tuple[float, float],
        orig_dims: Tuple[int, int],
        conf_threshold: float = 0.40,
        iou_threshold: float = 0.45
    ) -> List[Dict[str, Any]]:
        """
        Decodes raw YOLO tensor (1, 6, 8400), de-pads boxes to original image space,
        applies threshold filtering, and executes greedy NMS.
        """
        # Squeeze batch dimension: (6, 8400) -> (8400, 6)
        preds = np.squeeze(raw_output, axis=0).T
        
        # YOLO format: [xc, yc, w, h, score_class0, score_class1]
        boxes_xywh = preds[:, :4]
        class_scores = preds[:, 4:]
        
        # Class and max score per anchor
        class_ids = np.argmax(class_scores, axis=1)
        confidences = np.max(class_scores, axis=1)
        
        # Confidence threshold filter
        mask = confidences >= conf_threshold
        if not np.any(mask):
            return []
            
        boxes_xywh = boxes_xywh[mask]
        confidences = confidences[mask]
        class_ids = class_ids[mask]
        
        # Convert xc, yc, w, h to x1, y1, x2, y2 in padded coordinate space
        xc, yc, w, h = boxes_xywh[:, 0], boxes_xywh[:, 1], boxes_xywh[:, 2], boxes_xywh[:, 3]
        x1 = xc - (w / 2.0)
        y1 = yc - (h / 2.0)
        x2 = xc + (w / 2.0)
        y2 = yc + (h / 2.0)
        
        # De-pad coordinates back to original image space
        dw, dh = pad
        orig_w, orig_h = orig_dims
        
        x1 = np.clip((x1 - dw) / scale, 0, orig_w)
        y1 = np.clip((y1 - dh) / scale, 0, orig_h)
        x2 = np.clip((x2 - dw) / scale, 0, orig_w)
        y2 = np.clip((y2 - dh) / scale, 0, orig_h)
        
        boxes_orig = np.column_stack([x1, y1, x2, y2])
        
        # Run NMS per class
        detections = []
        unique_classes = np.unique(class_ids)
        
        for c in unique_classes:
            c_mask = class_ids == c
            c_boxes = boxes_orig[c_mask]
            c_scores = confidences[c_mask]
            
            keep_indices = nms_cpu(c_boxes, c_scores, iou_threshold)
            for idx in keep_indices:
                box = c_boxes[idx]
                detections.append({
                    "class_id": int(c),
                    "class_name": ID_TO_CLASS.get(int(c), f"class_{c}"),
                    "confidence": round(float(c_scores[idx]), 4),
                    "bbox": {
                        "xmin": round(float(box[0]), 2),
                        "ymin": round(float(box[1]), 2),
                        "xmax": round(float(box[2]), 2),
                        "ymax": round(float(box[3]), 2),
                    }
                })
                
        # Sort by confidence descending
        detections.sort(key=lambda x: x["confidence"], reverse=True)
        return detections

    def predict(
        self,
        img_bgr: np.ndarray,
        conf_threshold: float = 0.40,
        iou_threshold: float = 0.45
    ) -> List[Dict[str, Any]]:
        """End-to-end predict method for direct image arrays."""
        blob, scale, pad, orig_dims = self.preprocess(img_bgr)
        outputs = self.session.run(None, {self.input_name: blob})
        return self.postprocess(outputs[0], scale, pad, orig_dims, conf_threshold, iou_threshold)
