"""
train.py - Controlled Model Training Pipeline with MLflow Tracking
------------------------------------------------------------------
Orchestrates YOLOv8 training:
1. Enforces strict test-set isolation via leakage guard.
2. Applies global deterministic seeding.
3. Sets up local SQLite MLflow tracking.
4. Trains YOLOv8n with config-driven hyperparameters.
5. Logs training curves, validation metrics (mAP@50, mAP@50-95, per-class PR), and weights.
"""

import os
import sys
import argparse
from pathlib import Path
from typing import Any, Dict

# Ensure project root in sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import yaml
import mlflow
from ultralytics import YOLO

from src.utils.seed import set_seed
from src.utils.config import load_config
from src.utils.tracking import setup_mlflow, log_run_metadata
from src.utils.guard import guard_test_set_access


def verify_dataset_config_safety(dataset_yaml_path: str) -> None:
    """Ensures the dataset config does NOT contain a test set field."""
    with open(dataset_yaml_path, "r", encoding="utf-8") as f:
        data_cfg = yaml.safe_load(f)
    if "test" in data_cfg:
        raise PermissionError(
            "[LEAKAGE GUARD VIOLATION] dataset.yaml defines a 'test' split! "
            "The test set must remain untouched and inaccessible during training/validation."
        )


def train_model(config_path: str) -> Dict[str, Any]:
    """
    Executes model training for a given YAML configuration.
    """
    # 1. Enforce test set isolation
    guard_test_set_access("train.py")
    
    # 2. Load and validate config
    cfg = load_config(config_path)
    exp_cfg = cfg["experiment"]
    data_cfg = cfg["data"]
    model_cfg = cfg["model"]
    aug_cfg = cfg.get("augmentation", {})
    loss_cfg = cfg.get("loss", {})
    
    dataset_yaml = data_cfg["dataset_yaml"]
    verify_dataset_config_safety(dataset_yaml)
    
    # 3. Global deterministic seeding
    seed = exp_cfg.get("seed", 42)
    set_seed(seed)
    
    # 4. Setup MLflow tracking
    tracking_uri = exp_cfg.get("tracking_uri", "sqlite:///mlflow.db")
    setup_mlflow(experiment_name=exp_cfg["name"], db_path=tracking_uri)
    
    run_name = exp_cfg["run_id"]
    print(f"\n=======================================================")
    print(f"[START] Training Run: {run_name} (Seed: {seed})")
    print(f"        Changed Variable: {exp_cfg.get('changed_variable', 'none')}")
    print(f"=======================================================\n")
    
    with mlflow.start_run(run_name=run_name):
        # Log metadata & parameters
        log_run_metadata(
            run_id=run_name,
            changed_variable=exp_cfg.get("changed_variable", "none"),
            seed=seed,
            params={
                "model_weights": model_cfg["weights"],
                "epochs": model_cfg["epochs"],
                "patience": model_cfg["patience"],
                "img_size": data_cfg["img_size"],
                "batch_size": data_cfg["batch_size"],
                "optimizer": model_cfg["optimizer"],
                "lr0": model_cfg["lr0"],
                "lrf": model_cfg["lrf"],
                "momentum": model_cfg.get("momentum", 0.937),
                "weight_decay": model_cfg.get("weight_decay", 0.0005),
                "mosaic": aug_cfg.get("mosaic", 1.0),
                "scale": aug_cfg.get("scale", 0.5),
                "cls_gain": loss_cfg.get("cls_loss_gain", 0.5),
                "box_gain": loss_cfg.get("box_loss_gain", 7.5),
            }
        )
        
        # 5. Initialize YOLO detector
        model = YOLO(model_cfg["weights"])
        
        # 6. Execute training
        train_args = {
            "data": dataset_yaml,
            "epochs": model_cfg["epochs"],
            "patience": model_cfg["patience"],
            "imgsz": data_cfg["img_size"],
            "batch": data_cfg["batch_size"],
            "workers": data_cfg.get("workers", 2),
            "optimizer": model_cfg["optimizer"],
            "lr0": model_cfg["lr0"],
            "lrf": model_cfg["lrf"],
            "momentum": model_cfg.get("momentum", 0.937),
            "weight_decay": model_cfg.get("weight_decay", 0.0005),
            "warmup_epochs": model_cfg.get("warmup_epochs", 3.0),
            "cos_lr": model_cfg.get("cos_lr", False),
            "mosaic": aug_cfg.get("mosaic", 1.0),
            "scale": aug_cfg.get("scale", 0.5),
            "fliplr": aug_cfg.get("fliplr", 0.5),
            "hsv_h": aug_cfg.get("hsv_h", 0.015),
            "hsv_s": aug_cfg.get("hsv_s", 0.7),
            "hsv_v": aug_cfg.get("hsv_v", 0.4),
            "cls": loss_cfg.get("cls_loss_gain", 0.5),
            "box": loss_cfg.get("box_loss_gain", 7.5),
            "project": "models",
            "name": run_name,
            "seed": seed,
            "deterministic": True,
            "save": True,
            "verbose": True,
            "val": True,
        }
        
        results = model.train(**train_args)
        
        # 7. Extract validation metrics
        val_map50 = float(results.box.map50)
        val_map = float(results.box.map)
        val_p = float(results.box.mp)
        val_r = float(results.box.mr)
        
        # Per-class mAP50
        per_class_map50 = results.box.maps
        hat_map50 = float(per_class_map50[0]) if len(per_class_map50) > 0 else 0.0
        no_helmet_map50 = float(per_class_map50[1]) if len(per_class_map50) > 1 else 0.0
        
        metrics = {
            "val_mAP50": val_map50,
            "val_mAP50_95": val_map,
            "val_precision": val_p,
            "val_recall": val_r,
            "val_hat_mAP50": hat_map50,
            "val_no_helmet_mAP50": no_helmet_map50,
        }
        
        # Log to MLflow
        for m_name, m_val in metrics.items():
            mlflow.log_metric(m_name, m_val)
            
        # Log model artifacts
        run_save_dir = Path("models") / run_name
        if run_save_dir.exists():
            best_weight = run_save_dir / "weights" / "best.pt"
            if best_weight.exists():
                mlflow.log_artifact(str(best_weight), artifact_path="weights")
                
            results_csv = run_save_dir / "results.csv"
            if results_csv.exists():
                mlflow.log_artifact(str(results_csv), artifact_path="curves")
                
            # Log confusion matrix if generated
            cm_png = run_save_dir / "confusion_matrix.png"
            if cm_png.exists():
                mlflow.log_artifact(str(cm_png), artifact_path="figures")
                
        print(f"\n[SUCCESS] Run {run_name} completed.")
        print(f"          mAP@50:    {val_map50:.4f}")
        print(f"          mAP@50-95: {val_map:.4f}")
        print(f"          Hat mAP50: {hat_map50:.4f} | No-Helmet mAP50: {no_helmet_map50:.4f}")
        
        return metrics


def parse_args():
    parser = argparse.ArgumentParser(description="Train PPE Safety Detector")
    parser.add_argument("--config", type=str, required=True, help="Path to YAML experiment config")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    train_model(args.config)
